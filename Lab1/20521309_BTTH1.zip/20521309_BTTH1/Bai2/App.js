import React, { useState } from 'react';
import {
    View, Text, Button, Image, Platform, StyleSheet,
    FlatList,
    ImageBackground,
    SectionList
} from 'react-native';
import { fruits_vegetables, workouts } from './data';

export default Bai2 = () => {
    const [selectedExercises, setSelectedExercises] = useState([]);

    // TODO: 
    const toggleExerciseSelection = (exercise) => {
        const updatedSelectedExercises = Array.from(selectedExercises);
        if (updatedSelectedExercises.includes(exercise)) {
            const index = updatedSelectedExercises.indexOf(exercise);
            updatedSelectedExercises.splice(index, 1);
        } else {
            updatedSelectedExercises.push(exercise);
        }
        setSelectedExercises(updatedSelectedExercises);
    };

    // TODO:
    const renderButtonLabel = (exercise) => {
        return selectedExercises.includes(exercise) ? 'Deselect' : 'Select';
    };

    // TODO:
    const renderItem = ({ item }) => {
        const isSelected = selectedExercises.includes(item) ? 'Deselect' : 'Select';

        if (item.type) {
            return (
                <View style = {styles.bgItem}>
                    <Text style = {styles.txtItemName}>
                        {item.type}
                    </Text>
                    <View style={styles.btnSelect}>
                        <Button
                            title = {renderButtonLabel(item.type)}
                            onPress = {() => toggleExerciseSelection(item.type)}
                        />
                    </View>
                </View>
            );
        }
        else {
            return (
                <View style={styles.bgItem}>
                    <Text style={styles.txtItemName}>
                        {item}
                    </Text>

                    <View style={styles.btnSelect}>
                        <Button
                            title = {renderButtonLabel(item)}
                            onPress = {() => toggleExerciseSelection(item)}
                            />
                    </View>
                </View>
            );
        }
    };

    // TODO:
    const renderSectionHeader = ({ section }) => (
        <View style={styles.viewFruitAndVegeta}>
            <Text style={styles.txtFruitAndVegeta}>{section.title}</Text>
            <Image style={styles.imgFruit} source={{ uri: section.url }} />
        </View>
    );

    // TODO:
    return (
        <View style={styles.container}>
            <View style={styles.sectionOn}>
                <Text style={styles.ttFlatList}>
                    FlatList - Workouts
                </Text>

                <ImageBackground style={styles.backgroundImage}
                    source={{ uri: 'https://i.pinimg.com/564x/ed/5b/4a/ed5b4ade30c087928ab5f37354b099a2.jpg' }}>
                    <FlatList
                        data={workouts}
                        renderItem={renderItem}
                        keyExtractor={(item) => item.id}
                        style={styles.listView}
                    />
                </ImageBackground>

                <Text style={styles.ttSectionList}>
                    SectionList - Fruits & Vegetables
                </Text>

                <ImageBackground style = {styles.backgroundImage}
                    source={{ uri: 'https://i.pinimg.com/564x/1c/c5/37/1cc53754a6b10fe4d8b36828eb2bb6ea.jpg' }} >
                    <SectionList
                        sections={fruits_vegetables}
                        renderItem={renderItem}
                        renderSectionHeader={renderSectionHeader}
                        keyExtractor={(item, index) => item + index}
                        style={styles.listView}
                    />
                </ImageBackground>
            </View>
            <View style = {styles.sectionBottom}>
                <Text style = {styles.txtTitleSelected}> SELECTED EXCISES:{"\n"}
                    <Text style = {styles.txtSelected}> {selectedExercises.join(', ')}</Text>
                </Text>
            </View>
        </View>
    );
};

// TODO:
const styles = StyleSheet.create({
    container: {
        flex: 1,
        alignItems: 'center',
        justifyContent: 'flex-start',
        marginTop: 30,
    },
    sectionOn: {
        maxHeight: '80%',
        justifyContent: 'center',
        textAlignVertical: 'center',
        alignItems: 'center',
    },
    sectionBottom:{
        marginHorizontal: 10,
        justifyContent: 'center',
        textAlignVertical: 'center',
        alignItems: 'center',
    },
    backgroundImage: {
        flex: 1,
        // resizeMode: 'contain',
        justifyContent: 'center',
        marginBottom: 10,
        maxWidth: '100%',
    },
    listView: {
        ...Platform.select({
            ios: {
                maxHeight: 280,
            },
            android: {
                maxHeight: 300,
            },
            default: {
                maxHeight: 300,
            },
        }),
        marginBottom: 15,
        width: 360,
    },
    ttSectionList: {
        fontSize: 20,
        fontWeight: 'bold',
        color: 'blue',
        marginTop: 10,
        marginBottom: 5,
        justifyContent: 'center',
        textAlignVertical: 'center',
        textAlign: 'center',
    },
    ttFlatList: {
        fontSize: 20,
        fontWeight: 'bold',
        color: 'blue',
        marginBottom: 5,
    },
    bgItem: {
        flexDirection: 'row',
        backgroundColor: '#d9d9d9',
        borderRadius: 10,
        height: 57,
        margin: 5,
        justifyContent: 'space-between',
    },
    txtTitleSelected: {
        fontSize: 18,
        color: 'red',
        fontWeight: 'bold',
        marginTop: 10,
        justifyContent: 'center',
        textAlign: 'center',
        alignItems: 'center',
    },
    txtSelected:{
        fontSize: 17,
        color: "black",
        fontWeight: 'normal',
        justifyContent: 'center',
        textAlign: 'center',
        alignItems: 'center',

    },
    txtItemName: {
        fontSize: 17,
        justifyContent: 'center',
        textAlignVertical: 'center',
        marginLeft: 8,
    },
    btnSelect: {
        //height: 35,
        width: 95,
        justifyContent: 'center',
        AlignVertical: 'center',
        marginRight: 8,
        paddingVertical: 12,
    },
    txtFruitAndVegeta: {
        fontSize: 20,
        justifyContent: 'center',
        color: 'black',
        fontWeight: 'bold',
        marginVertical: 10,
        marginBottom: 3,
    },
    viewFruitAndVegeta: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        marginHorizontal: 90,
    },
    imgFruit: {
        width: 40,
        height: 40,
    },
});
