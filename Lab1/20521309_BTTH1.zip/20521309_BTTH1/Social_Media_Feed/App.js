import React, { useState } from 'react';
import {
  StyleSheet,
  Text,
  View,
  ScrollView,
  Image,
  TouchableOpacity,
  Button,

} from 'react-native';

// In4 Users
const postsData = [
  {
    id: 1,
    profileImage: 'https://i.pinimg.com/564x/d4/19/5b/d4195bea24a42f467121069756c1afa8.jpg',
    username: "Hi En",
    postText: "Hopeless... 😅",
    contentImage: 'https://i.pinimg.com/564x/09/5d/17/095d178d7a3fb7152ae991617cec12f9.jpg',
    likes: 20,
    liked: false,
    comments: 3,
    shares: 15,
  },
  {
    id: 2,
    profileImage: 'https://i.pinimg.com/564x/71/71/01/717101475f3de761a8fdc547510755b9.jpg',
    username: "hientn",
    postText: "I can do it! 🦢🦢",
    contentImage: 'https://i.pinimg.com/564x/82/b5/5a/82b55a1d820081a85c62d28a6d8dec9d.jpg',
    likes: 33,
    liked: false,
    comments: 12,
    shares: 5,
  },
  {
    id: 3,
    profileImage: 'https://i.pinimg.com/564x/54/29/64/5429649db56c2141684de58015b696a7.jpg',
    username: "Noo",
    postText: "Have a good day!",
    contentImage: 'https://i.pinimg.com/564x/84/f8/a5/84f8a53a14b53ad45071e32dc9245b64.jpg',
    likes: 60,
    liked: false,
    comments: 3,
    shares: 22,
  },
];

// MAIN
export default function App() {
  // Handle
  const [myPosts, setPosts] = useState([...postsData]);
  const [isClicked, setIsClicked] = useState(false);
  //
  const handleOnLikeClick = (postId) => {
    const updatedPosts = myPosts.map(post => {
      if (post.id == postId && !isClicked) {
        return {
          ...post,
          likes: post.likes + 1,
          liked: post.liked = true,
        }
      }
      else if(post.id == postId && isClicked){
        return {
          ...post,
          likes: post.likes - 1,
          liked: post.liked = false,
        }
      }
      return post;
    });
    setIsClicked(!isClicked);
    setPosts(updatedPosts);
  }

  //
  const handleOnShareClick = (postId) => {
    const updatedPosts = myPosts.map(post => {
      if (post.id === postId) {
        return {
          ...post,
          shares: post.shares + 1,
        }
      }
      return post;
    });
    setPosts(updatedPosts);
  }

  const handleOnCommentClick = (postId) => {
    const updatedPosts = myPosts.map(post => {
      if (post.id === postId) {
        return {
          ...post,
          comments: post.comments + 1,
        }
      }
      return post;
    });
    setPosts(updatedPosts);
  }

  // TODO: Show Main SCREEN
  return (
    <ScrollView style={myStyles.scrollView}>
      <View style={myStyles.container}>
        <View style={myStyles.bgTitle}>
          <Text style={myStyles.textTitle}>Social Media Feed</Text>
        </View>
        <View sytle={myStyles.myFeed}>
          {myPosts.map(post => (
            <View style={myStyles.stylePost} key={post.id}>
              <View style={myStyles.postHeader}>
                <Image source={{ uri: post.profileImage }} style={myStyles.profileImage} />
                <Text style={myStyles.myText}>{post.username}</Text>
              </View>
              <Text style={myStyles.postText}>{post.postText}</Text>
              <Image source={{ uri: post.contentImage }} style={myStyles.contentImage} />
              <View style={myStyles.statusContainer}>
                <Text style={myStyles.textStatusContainer}>{post.likes} <Text style={myStyles.textStatusContainer}> Likes </Text></Text>
                <Text style={myStyles.textStatusContainer}>{post.comments} <Text style={myStyles.textStatusContainer}> Comments </Text></Text>
                <Text style={myStyles.textStatusContainer}>{post.shares} <Text style={myStyles.textStatusContainer}> Shares </Text></Text>
              </View>

              <View style={myStyles.horizontalLine}></View>

              <View style={myStyles.interactiveContainer}>
                <TouchableOpacity style={myStyles.buttonContainer} onPress={() => handleOnLikeClick(post.id)} >
                  <Image source={!post.liked ? require('./images/icons/like.png')
                    : require('./images/icons/liked.png')} style={myStyles.buttonImage} />
                  <Text style={myStyles.textWithButton}>Likes</Text>
                </TouchableOpacity>

                <TouchableOpacity style={myStyles.buttonContainer} onPress={() => handleOnCommentClick(post.id)} >
                <Image source={require('./images/icons/comment.png')} style={myStyles.buttonImage} />
                  <Text style={myStyles.textWithButton}>Comments</Text>
                </TouchableOpacity>

                <TouchableOpacity style={myStyles.buttonContainer} onPress={() => handleOnShareClick(post.id)}>
                  <Image source={require('./images/icons/share.png')} style={myStyles.buttonImage} />
                  <Text style={myStyles.textWithButton}>Shares</Text>
                </TouchableOpacity>

              </View>
            </View>
          ))}
        </View>
      </View>
    </ScrollView>
  );
}

// Define styles
const myStyles = StyleSheet.create({
  container: {
    flex: 1,
    flexDirection: 'column',
    backgroundColor: '#f2f2f2',
  },
  scrollView: {
    flex: 1,
    backgroundColor: '#f2f2f2',
    marginTop: 35,
  },
  textStatusContainer: {
    color: '#a6a6a6',
    fontSize: 15,
  },
  postText: {
    fontSize: 18,
  },
  stylePost: {
    flex: 1,
    padding: 12,
    backgroundColor: 'white',
    borderRadius: 10,
    margin: 10,
    marginBottom: 0,
  },
  textWithButton: {
    fontSize: 15,
    justifyContent: 'center',
    fontWeight: 'bold',
    marginTop: 2,
  },
  myText: {
    fontSize: 19,
    marginVertical: 10,
    justifyContent: 'center',
    fontWeight: 'bold',
  },
  myFeed: {
    flex: 1,
  },
  bgTitle: {
    padding: 20,
    backgroundColor: 'blue',
  },
  textTitle: {
    textAlign: 'center',
    fontSize: 28,
    fontWeight: 'bold',
    color: 'white',
  },
  profileImage: {
    width: 45,
    height: 45,
    borderRadius: 25,
    marginRight: 13,
  },
  // styles thong tin nguoi post
  postHeader: {
    flexDirection: 'row',
    marginBottom: 10,
  },
  contentImage: {
    width: '100%',
    height: 250,
    borderRadius: 10,
    marginVertical: 10,
  },
  //
  statusContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between'
  },
  horizontalLine: {
    height: 1,
    backgroundColor: 'silver',
    marginVertical: 18,
  },
  buttonImage: {
    width: 25,
    height: 25,
    marginRight: 5,
    justifyContent: 'center',
  },
  buttonContainer: {
    flexDirection: 'row',
    justifyContent: 'center',
  },
  interactiveContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    margin: 5,
    padding: 5,
  }

});
