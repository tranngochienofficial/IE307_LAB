// data.js
export const fruits_vegetables = [
    {
        title: 'Fruits',
        url: 'https://cdn-icons-png.flaticon.com/512/1625/1625099.png',
        data: ['Banana', 'Orange', 'Grapes', 'Mango', 'Pineapple'],
    },
    {
        title: 'Vegetables',
        url: 'https://cdn-icons-png.flaticon.com/512/2153/2153788.png',
        data: ['Carrot', 'Broccoli', 'Spinach', 'Beets & Beet Greens', 'Kale'],
    },
];

export const workouts = [
    {
        id: '1',
        type: 'Push-ups',
    },
    {
        id: '2',
        type: 'Squats',
    },
    {
        id: '3',
        type: 'Planks',
    },
    {
        id: '4',
        type: 'Groiner',
    },
    {
        id: '5',
        type: 'Spider Crawl',
    },
    {
        id: '6',
        type: 'Glute Bridge',
    },
    {
        id: '7',
        type: 'Dumbbell rows',
    },
    {
        id: '8',
        type: 'Burpees',
    },
    {
        id: '9',
        type: 'Standing Long Jump',
    },
    {
        id: '10',
        type: 'Lunges',
    },
];
